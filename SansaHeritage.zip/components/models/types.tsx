export type RootStackParamList = {
  Login: undefined;
  SignUp: undefined;
  Dashboard: undefined;
  searchPage: undefined;
  ProductDetails: { itemId: string };
  CartPage: undefined;
  CheckoutPage: { billingDetails: Number };
  PaymentPage: { orderId: Number };
  Profile: undefined;
  WalletsPage: undefined;
  OrdersPage: undefined;
  SettingsPage: undefined;
  FavoritesPage: undefined;
  AboutUs: undefined;
  PrivacyPolicy: undefined;
  ForgotPassword: undefined
  BottomTabs: undefined
  CategoryScreen: { mainCategory: string };
  ResetPassword: { email: string};
  // Add other routes as needed
};