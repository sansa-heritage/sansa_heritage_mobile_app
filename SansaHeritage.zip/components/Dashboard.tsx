import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  FlatList,
  Modal,
  SafeAreaView,
  Dimensions,
} from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Slider from "@react-native-community/slider";
const { width } = Dimensions.get("window");
import { StyleSheet } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation } from '@react-navigation/native';
import { addToFavoritesList } from "./apiHelper/apiService";
import Rating from "./screens/RatingStars";
import { RootStackParamList } from "./models/types";
import eventBus from "./apiHelper/eventBus";
interface Params {
  mainCategory?: string;
  category?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
}

export default function Dashboard() {
  // 🔹 State
  const [newArrivals, setNewArrivals] = useState([]);
  const [trendingItems, setTrendingItems] = useState([]);

  const [showAllNew, setShowAllNew] = useState(false);
  const [showAllTrending, setShowAllTrending] = useState(false);

  const [searchText, setSearchText] = useState("");
  const [mainCategory, setMainCategory] = useState("");

  const [selectedCategory, setSelectedCategory] = useState("");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 0]);
  const [distanceRange, setDistanceRange] = useState([500, 2000]);

  const [modalVisible, setModalVisible] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const isFirstRender = useRef(true);
  // 🔹 API calls
  useEffect(() => {
    // Determine the mainCategory for each section
    const newArrivalCategory = mainCategory || "New Arrival";
    const trendingCategory = mainCategory || "Trending";
    console.log(mainCategory);

    // Build dynamic filters for both sections
    const dynamicFilters: any = {};
    if (searchText) dynamicFilters.searchText = searchText;
    if (selectedCategory) dynamicFilters.selectedCategory = selectedCategory;
    if (priceRange?.[0] || priceRange?.[1]) dynamicFilters.priceRange = priceRange;

    // Fetch sections
    fetchNewArrivals({
      mainCategory: newArrivalCategory,
      ...dynamicFilters
    });

    fetchTrending({
      mainCategory: trendingCategory,
      ...dynamicFilters
    });
  }, [mainCategory, searchText, selectedCategory, priceRange, distanceRange]);

  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  function addToFavorites(_id: number | undefined) {
    addToFavoritesList(_id);
    eventBus.emit("ITEM_REMOVED", { id: 123 });
  }
  const redirectToProductDetails = (id) => {
    navigation.navigate('ProductDetails', { itemId: id });
  };

  const fetchNewArrivals = async ({
    mainCategory,
    searchText,
    selectedCategory,
    priceRange
  }: {
    mainCategory?: string;
    searchText?: string;
    selectedCategory?: string;
    priceRange?: [number, number];
  }) => {
    try {
      const params: any = {};
      if (mainCategory) params.mainCategory = mainCategory;
      if (searchText) params.search = searchText;
      if (selectedCategory) params.category = selectedCategory;
      if (priceRange?.[0]) params.minPrice = priceRange[0];
      if (priceRange?.[1]) params.maxPrice = priceRange[1];
      console.log(params);

      const queryString = Object.keys(params)
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
        .join("&");

      const url = `https://ecappbe-sanasaheritages-projects.vercel.app/api/products${queryString ? "?" + queryString : ""}`;

      const res = await fetch(url);
      const data = await res.json();

      setNewArrivals(data || []);
    } catch (err) {
      console.error(err);
    }
  };


  const fetchTrending = async ({
    mainCategory,
    searchText,
    selectedCategory,
    priceRange
  }: {
    mainCategory?: string;
    searchText?: string;
    selectedCategory?: string;
    priceRange?: [number, number];
  }) => {
    try {
      const params: any = {}; // mainCategory fixed
      if (searchText) params.mainCategory = mainCategory;
      if (searchText) params.search = searchText;
      if (selectedCategory) params.category = selectedCategory;
      if (priceRange?.[0]) params.minPrice = priceRange[0];
      if (priceRange?.[1]) params.maxPrice = priceRange[1];

      const queryString = Object.keys(params)
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
        .join("&");

      const url = `https://ecappbe-sanasaheritages-projects.vercel.app/api/products${queryString ? "?" + queryString : ""}`;

      const res = await fetch(url);
      const data = await res.json();

      setTrendingItems(data || []);
    } catch (err) {
      console.error(err);
    }
  };



  // 🔹 Filter toggles
  const toggleShowAllNew = () => setShowAllNew(!showAllNew);
  const toggleShowAllTrending = () => setShowAllTrending(!showAllTrending);

  const itemsToShowNew = showAllNew ? newArrivals : newArrivals.slice(0, 4);
  const itemsToShowTrending = showAllTrending ? trendingItems : trendingItems.slice(0, 4);

  const handleSearchChange = (text: string) => setSearchText(text);
  const assignFilterItem = (category: string) => {
    setSelectedCategory(category);
    setMainCategory("");
  }

  const applyFilter = () => {
    setModalVisible(false);

    fetchNewArrivals({
      mainCategory,
      searchText,
      selectedCategory,
      priceRange
    });

    fetchTrending({
      mainCategory,
      searchText,
      selectedCategory,
      priceRange
    });
  };


  const navigateToCategory = (category: string) => {
    navigation.navigate("CategoryScreen", { mainCategory: category });
  };
  const renderPrice = (price, discount) => {
    const discountedPrice = price - (price * discount / 100);
    return (
      <View>
        <View style={styles.priceContainer}>
          <Text style={styles.discountedPrice}>₹{discountedPrice?.toFixed(2)}</Text>
          <Text style={styles.originalPrice}>₹{price?.toFixed(2)}</Text>
        </View>
        <Text style={styles.discountPercent}>{discount}% off</Text>
      </View>
    );
  };
  // 🔹 Shared product renderer
  const renderProductCard = (item) => (
    <TouchableOpacity
      style={styles.newArrivalItem}
      onPress={() => redirectToProductDetails(item._id)}
    >
      {item.image ? (
        <Image source={{ uri: item.image }} style={styles.itemImage} />
      ) : (
        <Image source={require("../assets/images/logo.png")} style={styles.itemImage} />
      )}

      <TouchableOpacity
        style={styles.favoriteIcon}
        onPress={() => addToFavorites(item._id)}
      >
        <MaterialIcons name="favorite" size={24} color="red" />
      </TouchableOpacity>

      <View style={styles.itemContainer}>
        <Text style={styles.itemTitle}>
          {item.name.length > 20 ? item.name.substring(0, 15) + "..." : item.name}
        </Text>
        <Text style={styles.itemDescription}>
          {item?.description?.length > 20
            ? item?.description?.substring(0, 18) + "..."
            : item?.description}
        </Text>
        {renderPrice(item.price, item.discount)}
        {item.rating !== undefined && <Rating value={item.rating} />}
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: 70 }}>
        {/* 🔹 Title */}
        <View style={styles.titleSection}>
          <Text style={styles.title}>Explore</Text>
          <Text style={styles.subtitle}>best Outfits for you</Text>
        </View>

        {/* 🔹 Search */}
        <View style={styles.searchSection}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search items..."
            value={searchText}
            onChangeText={handleSearchChange}
          />
          <TouchableOpacity
            style={styles.searchIconWrapper}
            onPress={() => setModalVisible(true)}
          >
            <MaterialIcons name="filter-list" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {searchText ? (
          <View>
            <Text>{"Recent searches"}</Text>
            <Text>{"Search results showing for "}{searchText}</Text>
          </View>
        ) : null}

        {/* 🔹 Categories */}
        <View style={styles.categoriesSection}>
          {[
            { label: "Sarees", value: "Saree" },
            { label: "Dress Materials", value: "dress" },
            { label: "Kurta Suit Sets", value: "kurta" },
            { label: "Dupattas", value: "dupatta" },
          ].map((category, index) => (
            <TouchableOpacity
              key={index}
              style={styles.categoryCard}
              onPress={() => assignFilterItem(category.value)}
            >
              <Text style={styles.categoryLabel}>{category.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* 🔹 New Arrival Section */}
        <View style={styles.newArrivalSection}>
          <View style={styles.newArrivalHeader}>
            <Text style={styles.newArrivalTitle}>New Arrival</Text>
            <TouchableOpacity onPress={(e) => navigateToCategory('New Arrival')} style={styles.button}>
              <Text style={styles.seeAllText}>{showAllNew ? "Show Less" : "See All"}</Text>
            </TouchableOpacity>
          </View>
          {itemsToShowNew.length === 0 ? (
            <Text style={styles.seeAllText}>No Records found</Text>
          ) : (
            <FlatList
              nestedScrollEnabled
              data={itemsToShowNew}
              keyExtractor={(item, index) => index.toString()}
              numColumns={2}
              columnWrapperStyle={styles.columnWrapper}
              renderItem={({ item }) => renderProductCard(item)}
            />
          )}
        </View>

        {/* 🔹 Trending Section */}
        <View style={styles.newArrivalSection}>
          <View style={styles.newArrivalHeader}>
            <Text style={styles.newArrivalTitle}>Trending</Text>
            <TouchableOpacity onPress={(e) => navigateToCategory('Trending')} style={styles.button}>
              <Text style={styles.seeAllText}>{showAllTrending ? "Show Less" : "See All"}</Text>
            </TouchableOpacity>
          </View>
          {itemsToShowTrending.length === 0 ? (
            <Text style={styles.seeAllText}>No Records found</Text>
          ) : (
            <FlatList
              nestedScrollEnabled
              data={itemsToShowTrending}
              keyExtractor={(item, index) => index.toString()}
              numColumns={2}
              columnWrapperStyle={styles.columnWrapper}
              renderItem={({ item }) => renderProductCard(item)}
            />
          )}
        </View>
      </ScrollView>

      {/* 🔹 Filter Modal */}
      <Modal
        animationType="slide"
        transparent
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.clearText}>Clear</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Filters</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <MaterialIcons name="menu" size={24} color="black" />
              </TouchableOpacity>
            </View>

            {/* Category Filter */}
            <Text style={styles.filterSectionTitle}>Category</Text>
            <View style={styles.categoryFilter}>
              <TouchableOpacity style={styles.categoryFilterButton} onPress={(e) => navigateToCategory('New Arrival')}>
                <Text style={styles.categoryFilterText}>New Arrival</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.categoryFilterButton} onPress={(e) => navigateToCategory('Trending')} >
                <Text style={styles.categoryFilterText}>Trending</Text>
              </TouchableOpacity>
              {/* <TouchableOpacity style={styles.categoryFilterButton}>
                <Text style={styles.categoryFilterText}>Featured Products</Text>
              </TouchableOpacity> */}
            </View>

            {/* Price Filter */}
            <Text style={styles.filterSectionTitle}>Pricing</Text>
            <View style={styles.sliderSection}>
              <Text style={styles.sliderLabel}>${priceRange[0]}</Text>
              <Slider
                style={styles.slider}
                minimumValue={50}
                maximumValue={200}
                value={priceRange[0]}
                onValueChange={(value) => setPriceRange([value, priceRange[1]])}
                minimumTrackTintColor="#ff6f61"
              />
              <Text style={styles.sliderLabel}>${priceRange[1]}</Text>
            </View>

            {/* Distance Filter */}
            <Text style={styles.filterSectionTitle}>Distance</Text>
            <View style={styles.sliderSection}>
              <Text style={styles.sliderLabel}>{distanceRange[0]}m</Text>
              <Slider
                style={styles.slider}
                minimumValue={500}
                maximumValue={2000}
                value={distanceRange[0]}
                onValueChange={(value) => setDistanceRange([value, distanceRange[1]])}
                minimumTrackTintColor="#ff6f61"
              />
              <Text style={styles.sliderLabel}>{distanceRange[1]}m</Text>
            </View>

            <TouchableOpacity style={styles.applyButton} onPress={applyFilter}>
              <Text style={styles.applyButtonText}>Apply Filter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </View>
  );
}
const styles = StyleSheet.create({
  itemContainer: {
    padding: 12,
    marginTop: 8,
    backgroundColor: '#fff',
    borderRadius: 10,
  },
  itemTitle: {
    marginTop: 5,
    fontSize: 16,
    textAlign: 'left',
    fontWeight: 'bold',
    color: '#222',
  },
  itemDescription: {
    marginTop: 4,
    fontSize: 14,
    fontWeight: '300',
    textAlign: 'left',
    color: '#555',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  discountedPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginRight: 8,
  },
  originalPrice: {
    fontSize: 16,
    color: '#888',
    textDecorationLine: 'line-through',
    marginRight: 8,
  },
  discountPercent: {
    fontSize: 16,
    fontWeight: '600',
    color: 'green',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  menuMaincontainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 25,
    marginRight: 10,
    borderColor: '#00A0FF',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  logOut: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    marginTop: 60
  },
  menuButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  brandLogo: {
    marginTop: '43%',
  },
  locationText: {
    fontSize: 16,
    marginHorizontal: 10,
    flex: 1,
    textAlign: 'center',
  },
  favoriteIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  menuContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 100,
    height: '100%',
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 1,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  newArrivalItem: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 8,
    marginBottom: 15,
  },
  menuContent: {
    flex: 1,
    padding: 20,
  },
  menuCloseButton: {
    position: 'absolute',
    top: 20,
    right: 20,
  },
  menuTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 20,
  },
  menuItems: {
    marginTop: 60,
    padding: 10,
    width: '100%',
  },
  menuItemText: {
    fontSize: 18,
    paddingVertical: 10,
    marginLeft: 20
  },
  menuCloseText: {
    fontSize: 16,
    color: '#ff6f61',
    textAlign: 'right'
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 15,
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    width: '100%',
  },
  rightColumn: {
    flex: 1,
    justifyContent: 'center',
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  userDesignation: {
    fontSize: 14,
    color: '#666',
  },
  actionButton: {
    padding: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    elevation: 3,
  },
  logo: {
    width: 80,
    height: 50,
    resizeMode: "contain",
  },
  titleSection: {
    marginVertical: 10,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 18,
    color: '#aaa',
  },
  searchSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#f2f2f2',
    borderRadius: 10,
    paddingLeft: 16,
    paddingRight: 0,
  },

  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 10,
  },

  searchIconWrapper: {
    backgroundColor: '#151515',
    padding: 10,
    borderRadius: 10,
    marginLeft: 10,
  },

  categoriesSection: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginVertical: 10,
  },
  categoryCard: {
    width: "45%",
    margin: 8,
    paddingVertical: 20,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#f9f9f9",
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  categoryLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    textAlign: "center",
  },
  categoryItem: {
    alignItems: 'center',
    padding: 10,
  },
  newArrivalSection: {
    marginTop: 20,
  },
  newArrivalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  newArrivalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  seeAllText: {
    fontSize: 14,
    color: '#151515',
  },
  itemImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
  },
  itemLabel: {
    marginTop: 10,
    fontSize: 16,
  },
  itemPrice: {
    marginTop: 5,
    fontSize: 14,
    color: '#888',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  clearText: {
    fontSize: 16,
    color: '#151515',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  filterSectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  categoryFilter: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  categoryFilterButton: {
    backgroundColor: '#151515',
    padding: 10,
    borderRadius: 20,
    width: '50%',
  },
  categoryFilterButtonInactive: {
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderRadius: 20,
  },
  categoryFilterText: {
    color: '#fff',
    fontSize: 14,
    textAlign: "center",
  },
  categoryImage: {
    height: 30,
    width: 30
  },
  sliderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  slider: {
    flex: 1,
    marginHorizontal: 20,
  },
  sliderLabel: {
    fontSize: 14,
    color: '#888',
  },
  applyButton: {
    backgroundColor: '#151515',
    borderRadius: 35,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  applyButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  button: {
    marginTop: 10,
    alignSelf: "center",
  },
});