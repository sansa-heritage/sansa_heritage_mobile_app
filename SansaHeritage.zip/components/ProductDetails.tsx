import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, Image, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import config from '../config/config';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { addToFavoritesList } from './apiHelper/apiService';
import { Dimensions } from 'react-native';
import { RootStackParamList } from './models/types';
import eventBus from './apiHelper/eventBus';

const { width, height } = Dimensions.get('window');
interface ProductDetails {
  image: string;
  name: string;
  description: string;
  price: number;
  discount: number;
  availableColors: string[];
  avaialbleSizes: string[];
  _id: number;
  details: string[];
}


const ProductPage = () => {
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [productDetails, setProductDetails] = useState<ProductDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  type ProductDetailsRouteProp = RouteProp<RootStackParamList, 'ProductDetails'>;
  const route = useRoute<ProductDetailsRouteProp>();
  const { itemId } = route.params;
  const navigation = useNavigation<StackNavigationProp<RootStackParamList, 'ProductDetails'>>();
  const [selectedSize, setSelectedSize] = useState<string | null>(null);

  useEffect(() => {
    const fetchToken = async () => {
      try {
        const storedToken = await AsyncStorage.getItem('authToken');
        const storedUserId = await AsyncStorage.getItem('userID');

        if (storedToken) setToken(storedToken);
        if (storedUserId) setUserId(storedUserId);

        if (!storedToken) {
          console.warn('No token found in AsyncStorage');
        }
      } catch (err) {
        console.error('Error fetching token:', err);
      }
    };

    const fetchProductDetails = async () => {
      if (!token) return; // Ensure token is available before making the request
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(`${config.baseURL}api/products/${itemId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        setProductDetails(data);
      } catch (err) {
        setError('Failed to load product details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    const initialize = async () => {
      await fetchToken();
      if (token) {
        fetchProductDetails();
      }
    };

    initialize();
  }, [itemId, token]);

  const handleAddToCart = async () => {
    if (!token || !userId) {
      Alert.alert('Error', 'Token or user ID is missing. Unable to add product to cart.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`${config.baseURL}api/cart/add-to-cart`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId,
          productId: itemId,
          color: selectedColor,
          size: selectedSize
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      Alert.alert('Success', 'Product added to cart successfully!');
      eventBus.emit("ITEM_REMOVED", { id: 123 });
      navigation.navigate('CartPage');
    } catch (err) {
      setError('Failed to add product to cart. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  function addToFavorites(_id: number | undefined) {
    addToFavoritesList(_id)
    eventBus.emit("ITEM_REMOVED", { id: 123 });
  }

  const renderPrice = (price, discount) => {
    const discountedPrice = price - (price * discount / 100);
    return (
      <View style={styles.priceContainer}>
        <Text style={styles.discountedPrice}>₹{discountedPrice?.toFixed(2)}</Text>
        <Text style={styles.originalPrice}>₹{price?.toFixed(2)}</Text>
        <Text style={styles.discountPercent}>{discount}% off</Text>
      </View>
    );
  };
  return (
    <ScrollView
      contentContainerStyle={styles.scrollContainer}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.container}>
        {productDetails ? (
          <>
            {/* Image & Favorite */}
            <View style={styles.imageContainer}>
              <Image source={{ uri: productDetails?.image }} style={styles.image} />
              <View style={styles.header}>
                <TouchableOpacity
                  style={styles.favoriteButton}
                  onPress={() => addToFavorites(productDetails?._id)}
                >
                  <FontAwesome name="heart" size={24} color="red" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Product Info */}
            <View style={styles.BottomContainer}>
              <View style={styles.itemDetailsContainer}>
                <Text style={styles.title}>{productDetails?.name}</Text>
              </View>

              {/* Price */}
              <View style={styles.priceSection}>
                {renderPrice(productDetails?.price, productDetails?.discount)}
              </View>

              {/* Colors */}
              {productDetails?.availableColors?.length > 0 && (
                <View style={styles.colorOptions}>
                  <Text style={styles.sectionTitle}>Select Color</Text>
                  <View style={styles.sizeOptions}>
                    {productDetails?.availableColors?.map((color, index) => (
                      <TouchableOpacity
                        key={index}
                        style={[
                          styles.colorOption,
                          selectedColor === color && styles.selectedColorOption,
                        ]}
                        onPress={() => setSelectedColor(color)}
                      >
                        <View
                          style={{
                            backgroundColor: color.toLowerCase(),
                            width: 30,
                            height: 30,
                            borderRadius: 15,
                          }}
                        />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              {/* Sizes */}
              {productDetails?.avaialbleSizes?.length > 0 && (
                <View style={styles.sizeContainer}>
                  <Text style={styles.sectionTitle}>Select Size</Text>
                  <View style={styles.sizeOptions}>
                    {productDetails?.avaialbleSizes?.map((size, index) => (
                      <TouchableOpacity
                        key={index}
                        style={[
                          styles.sizeOption,
                          selectedSize === size && styles.selectedSizeOption,
                        ]}
                        onPress={() => setSelectedSize(size)}
                      >
                        <Text
                          style={[
                            styles.sizeText,
                            selectedSize === size && styles.selectedSizeText,
                          ]}
                        >
                          {size}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              {/* Details */}
              <View style={styles.detailsContainer}>
                <Text style={styles.sectionTitle}>Product Details</Text>
                {(productDetails?.details ?? []).length > 0 ? (
                  productDetails?.details.map((detail, index) => (
                    <Text key={index} style={styles.detailText}>
                      • {detail}
                    </Text>
                  ))
                ) : (
                  <Text style={styles.detailText}>
                    No additional details available.
                  </Text>
                )}
              </View>
            </View>

            {/* Add to Cart Button */}
            <TouchableOpacity
              style={styles.addToCartButton}
              onPress={handleAddToCart}
            >
              <Text style={styles.addToCartButtonText}>Add to Cart</Text>
            </TouchableOpacity>
          </>
        ) : (
          <Text style={styles.detailText}>No product data available.</Text>
        )}
      </View>
    </ScrollView>

  );
};

const styles = StyleSheet.create({
  itemDetailsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  scrollContainer: {
    flexGrow: 1,
    backgroundColor: 'white',
    paddingBottom: 70
  },
  container: {
    flex: 1,
    backgroundColor: '#3335470F',
    padding: 16,
  },
  BottomContainer: {
    backgroundColor: '#fff',
    marginTop: -30,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    width: '100%',
  },
  imageContainer: {
    position: 'relative',
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: 'gray',
    borderRadius: 8,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: undefined,
    aspectRatio: 1,
    resizeMode: 'contain',
  },
  header: {
    position: 'absolute',
    top: 10, // Adjust to position inside the image
    right: 10, // Move to the right corner
    backgroundColor: 'rgba(255, 255, 255, 0.6)', // Optional: Background for visibility
    borderRadius: 20, // Optional: Rounded button
    padding: 5, // Optional: Space around icon
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  discountedPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginRight: 8,
  },
  originalPrice: {
    fontSize: 16,
    color: '#888',
    textDecorationLine: 'line-through',
    marginRight: 8,
  },
  discountPercent: {
    fontSize: 16,
    fontWeight: '600',
    color: 'green',
  },
  favoriteButton: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
    padding: 9,
  },
  description: {
    marginBottom: 16,
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 20,
    textAlign: 'left',
    padding: 9,
  },
  priceSection: {
    marginBottom: 10,
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 20,
    textAlign: 'left',
    padding: 9,
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
    padding: 9,
  },
  colorOptions: {
    marginTop: 5,
    padding: 9,
  },
  colorOption: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 15,
    marginRight: 8,
    padding: 4,
  },
  selectedColorOption: {
    borderWidth: 2,
    borderColor: 'blue',
  },
  addToCartButton: {
    backgroundColor: '#151515',
    borderRadius: 30,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  addToCartButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  sizeContainer: {
    marginTop: 5,
    padding: 9,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  detailsContainer: {
    marginTop: 20,
    paddingHorizontal: 10
  },
  detailText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5
  },
  sizeOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },

  sizeOption: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: '#fff',
    elevation: 2, // shadow for Android
  },

  selectedSizeOption: {
    borderColor: '#007AFF',
    backgroundColor: '#E6F0FF',
  },

  sizeText: {
    fontSize: 14,
    color: '#333',
  },

  selectedSizeText: {
    color: '#007AFF',
    fontWeight: '600',
  },

});

export default ProductPage;
